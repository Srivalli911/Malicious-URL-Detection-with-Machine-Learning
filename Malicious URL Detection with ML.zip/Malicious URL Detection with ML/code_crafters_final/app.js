const express = require('express');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const analysisRoutes = require('./routes/analysis');
const modelRoutes = require('./routes/model');
const reportRoutes = require('./routes/report');
const feedbackRoutes = require('./routes/feedback');

const app = express();

// Connect Database
connectDB();

// Init Middleware
app.use(express.json());

// Define Routes
app.use('/api/auth', authRoutes);
app.use('/api/analysis', analysisRoutes);
app.use('/api/model', modelRoutes);
app.use('/api/report', reportRoutes);
app.use('/api/feedback', feedbackRoutes);


app.use((req, res) => {
    console.log(`Received ${req.method} request for ${req.url}`);
    res.status(404).send('Not Found');
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
