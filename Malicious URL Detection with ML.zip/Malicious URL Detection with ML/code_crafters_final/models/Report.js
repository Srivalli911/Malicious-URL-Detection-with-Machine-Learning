

const mongoose = require('mongoose');

const ReportSchema = new mongoose.Schema({
    analysisId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Analysis',
        required: true
    },
    reportContent: {
        type: String,
        required: true
    },
    format: {
        type: String,
        default: 'standard'
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Report', ReportSchema);