const mongoose = require('mongoose');

const AnalysisSchema = new mongoose.Schema({
    url: { type: String, required: true },
    result: { type: String, required: true },
    feedback: { type: String }
});

module.exports = mongoose.model('Analysis', AnalysisSchema);
