# predict.py

import sys
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer

# Load the model and vectorizer
model = joblib.load('utils/model.pkl')
vectorizer = joblib.load('utils/vectorizer.pkl')

def predict(url):
    # Vectorize the input URL
    url_features = vectorizer.transform([url])

    # Predict the type of the URL
    result = model.predict(url_features)[0] 
    print(result)  # Output the prediction

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print("Usage: python predict.py <url>")
        sys.exit(1)
    
    url = sys.argv[1]
    predict(url)
