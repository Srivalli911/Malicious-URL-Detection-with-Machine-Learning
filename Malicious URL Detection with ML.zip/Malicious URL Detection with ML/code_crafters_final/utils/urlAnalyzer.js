const { PythonShell } = require('python-shell');

function analyzeMaliciousProbability(url) {
  return new Promise((resolve, reject) => {
    let options = {
      args: [url]
    };

    PythonShell.run('utils/predict.py', options, function (err, results) {
      if (err) reject(err);
      resolve(results[0]);
    });
  });
}

module.exports = { analyzeMaliciousProbability };
