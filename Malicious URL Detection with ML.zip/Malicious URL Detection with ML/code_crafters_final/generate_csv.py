import pandas as pd

data = {
    'url': [
        'br-icloud.com.br',
        'mp3raid.com/music/krizz_kaliko.html',
        'bopsecrets.org/rexroth/cr/1.htm',
        'http://www.garage-pirenne.be/index.php?option=com_content&view=article&id=70&vsig70_0=15',
        'espn.go.com/nba/player/_/id/3457/brandon-rush'
    ],
    'type': [
        'phishing',
        'benign',
        'benign',
        'defacement',
        'benign'
    ]
}

df = pd.DataFrame(data)
df.to_csv('malicious_url_dataset.csv', index=False)


