import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from pymongo import MongoClient
import os

# Connect to MongoDB
client = MongoClient(os.getenv('MONGO_URI'))
db = client['malicious_url_db']
feedback_collection = db['feedbacks']
analysis_collection = db['analyses']

# Load feedback and analyses
feedbacks = list(feedback_collection.find())
analyses = list(analysis_collection.find())

# Process feedback and analyses to create a new training dataset
data = []
for feedback in feedbacks:
    analysis = next((a for a in analyses if a['_id'] == feedback['analysisId']), None)
    if analysis:
        label = 1 if feedback['feedback'] == 'false_negative' else 0
        data.append({'url': analysis['url'], 'label': label})

df = pd.DataFrame(data)

# Feature extraction
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(df['url'])
y = df['label']

# Train the model
model = LogisticRegression()
model.fit(X, y)

# Save the model and vectorizer
joblib.dump(model, 'utils/model.pkl')
joblib.dump(vectorizer, 'utils/vectorizer.pkl')
