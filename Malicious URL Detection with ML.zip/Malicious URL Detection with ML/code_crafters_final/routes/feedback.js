const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Feedback = require('../models/Feedback');
const Analysis = require('../models/Analysis');

// @route   POST /api/feedback
// @desc    Submit feedback for a specific URL analysis
// @access  Private
router.post('/', auth, async (req, res) => {
    const { analysisId, feedback } = req.body;

    try {
        const analysis = await Analysis.findById(analysisId);
        if (!analysis) {
            return res.status(404).json({ msg: 'Analysis not found' });
        }

        const newFeedback = new Feedback({
            analysisId,
            userId: req.user.id,
            feedback
        });

        await newFeedback.save();
        res.json(newFeedback);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// @route   GET /api/feedback/:analysisId
// @desc    Retrieve feedback for a specific URL analysis
// @access  Private
router.get('/:analysisId', auth, async (req, res) => {
    try {
        const feedbacks = await Feedback.find({ analysisId: req.params.analysisId });
        res.json(feedbacks);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;
