const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// @route   POST /api/user/data-deletion
// @desc    Requests deletion of all personal data associated with the user's account.
// @access  Private
router.post('/data-deletion', auth, async (req, res) => {
    try {
        
        const userId = req.user.id;

       
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ msg: 'User not found' });
        }

        
        await user.remove();

        res.json({ status: 'success', message: 'Data deletion requested' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;
