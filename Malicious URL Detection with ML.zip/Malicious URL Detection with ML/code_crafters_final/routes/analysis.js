const express = require('express');
const router = express.Router();
const Analysis = require('../models/Analysis');
const auth = require('../middleware/auth');
const { spawn } = require('child_process');
const path = require('path');

const pythonScriptPath = path.join(__dirname, '..', 'utils', 'predict.py');

// @route   POST /api/analysis
// @desc    Analyze URL
// @access  Private
router.post('/', auth, async (req, res) => {
    const { url } = req.body;

    try {
        
        const pythonProcess = spawn('python', [pythonScriptPath, url]);

        pythonProcess.stdout.on('data', async (data) => {
            const result = data.toString().trim(); //
            const analysis = new Analysis({ url, result });

            try {
                await analysis.save();
                res.json(analysis);
            } catch (err) {
                console.error(err.message);
                res.status(500).send('Error saving analysis');
            }
        });

        pythonProcess.stderr.on('data', (data) => {
            console.error(`Error from Python script: ${data}`);
            res.status(500).send('Server error');
        });

    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});
router.delete('/:analysisId', auth, async (req, res) => {
    try {
        const { analysisId } = req.params;
        const analysis = await Analysis.findById(analysisId);

        if (!analysis) {
            return res.status(404).json({ msg: 'Analysis not found' });
        }

        await Analysis.findByIdAndDelete(analysisId);

        res.json({ status: 'success', message: 'Analysis deleted' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// @route   PUT /api/analysis/:analysisId
// @desc    Updates details or reanalyzes an existing URL analysis
// @access  Private
router.put('/:analysisId', auth, async (req, res) => {
    try {
        const { analysisId } = req.params;
        const { url } = req.body;

        
        if (!url) {
            return res.status(400).json({ msg: 'URL is required' });
        }

       
        let analysis = await Analysis.findById(analysisId);
        if (!analysis) {
            return res.status(404).json({ msg: 'Analysis not found' });
        }

        
        analysis.url = url;

        
        await analysis.save();

        res.json({ status: 'success', message: 'Analysis updated', updatedAnalysis: analysis });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
});



module.exports = router;
