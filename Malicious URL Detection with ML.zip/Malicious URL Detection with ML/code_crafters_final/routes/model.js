const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Model = require('../models/Model');

// @route   POST /api/model
// @desc    Upload new machine learning model
// @access  Private
router.post('/', auth, async (req, res) => {
  const { name, description, accuracy } = req.body;

  try {
    const newModel = new Model({
      name,
      description,
      accuracy,
      uploadedBy: req.user.id,
    });

    await newModel.save();
    res.json(newModel);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// @route   GET /api/model/:id
// @desc    Get details of a specific machine learning model
// @access  Public (for demonstration purposes; should be Private in actual deployment)
router.get('/:id', async (req, res) => {
  try {
    const model = await Model.findById(req.params.id);
    if (!model) {
      return res.status(404).json({ msg: 'Model not found' });
    }
    res.json(model);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
