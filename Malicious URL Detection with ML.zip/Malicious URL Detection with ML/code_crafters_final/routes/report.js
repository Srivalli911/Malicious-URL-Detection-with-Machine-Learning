const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Report = require('../models/Report');
const Analysis = require('../models/Analysis');
const debug = require('debug')('app:report');

// @route   POST /api/report/:analysisId
// @desc    Generates a detailed report for a specific URL analysis
// @access  Private

router.post('/:analysisId', auth, async (req, res) => {
    debug(`Received POST request for analysis ID: ${req.params.analysisId}`);
    try {
        const { analysisId } = req.params;
        const { additionalComments, includeGraphs, reportFormat, riskScore, explanation, detectedFeatures } = req.body;

        const analysis = await Analysis.findById(analysisId);
        if (!analysis) {
            return res.status(404).json({ msg: 'Analysis not found' });
        }

        let reportContent = `Report for URL: ${analysis.url}\n`;
        reportContent += `Risk Score: ${riskScore || analysis.riskScore}\n`;
        reportContent += `Detected Features: ${detectedFeatures || analysis.features}\n`;
        reportContent += `Explanation: ${explanation || analysis.explanation}`;

        if (additionalComments) {
            reportContent += `\nAdditional Comments: ${additionalComments}`;
        }

        if (includeGraphs) {
            reportContent += '\nGraphs included in full report';
        }

        if (reportFormat === 'detailed') {
            reportContent += '\nThis is a detailed report...';
        }

        const newReport = new Report({
            analysisId,
            reportContent,
            format: reportFormat
        });

        await newReport.save();
        res.json(newReport);
    } catch (err) {
        debug(`Error in POST /:analysisId: ${err.message}`);
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

// @route   GET /api/report/:reportId
// @desc    Retrieves the detailed report for a specific analysis
// @access  Private
router.get('/:reportId', auth, async (req, res) => {
    debug(`Received GET request for report ID: ${req.params.reportId}`);
    try {
        const report = await Report.findById(req.params.reportId);
        if (!report) {
            return res.status(404).json({ msg: 'Report not found' });
        }
        res.json(report);
    } catch (err) {
        debug(`Error in GET /:reportId: ${err.message}`);
        console.error(err.message);
        res.status(500).send('Server error');
    }
});

module.exports = router;